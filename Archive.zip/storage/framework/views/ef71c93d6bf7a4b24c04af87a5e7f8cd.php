<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'content' => null,
    'position' => 'top',
    'delay' => 200,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'content' => null,
    'position' => 'top',
    'delay' => 200,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $positions = [
        'top' => 'bottom-full mb-2 left-1/2 -translate-x-1/2',
        'bottom' => 'top-full mt-2 left-1/2 -translate-x-1/2',
        'left' => 'right-full mr-2 top-1/2 -translate-y-1/2',
        'right' => 'left-full ml-2 top-1/2 -translate-y-1/2',
    ];
?>

<div
    x-data="{ show: false }"
    @mouseenter="setTimeout(() => show = true, <?php echo e($delay); ?>)"
    @mouseleave="show = false"
    @focusin="show = true"
    @focusout="show = false"
    class="relative inline-flex"
>
    <?php echo e($slot); ?>


    <div
        x-show="show"
        x-cloak
        x-transition:enter="transition ease-out duration-100"
        x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100"
        class="absolute z-[var(--z-tooltip)] <?php echo e($positions[$position] ?? $positions['top']); ?> px-2 py-1 text-xs text-white bg-[var(--color-text-primary)] rounded-[var(--radius-sm)] whitespace-nowrap pointer-events-none shadow-lg"
    >
        <?php echo e($content ?? $attributes->get('content', '')); ?>

    </div>
</div>
<?php /**PATH /Users/maystro/Desktop/MyData/dev/web-apps/laravel13/charity/resources/views/components/ui/tooltip.blade.php ENDPATH**/ ?>