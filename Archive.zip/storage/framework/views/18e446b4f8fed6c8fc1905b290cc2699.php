<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'steps' => [],
    'current' => 1,
    'orientation' => 'horizontal',
    'size' => 'md',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'steps' => [],
    'current' => 1,
    'orientation' => 'horizontal',
    'size' => 'md',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $isVertical = $orientation === 'vertical';
    $connectorClass = $isVertical ? '' : 'flex-1 h-0.5';
?>

<div class="<?php echo e($isVertical ? 'flex flex-col gap-0' : 'flex items-center gap-0'); ?>" <?php echo e($attributes); ?>>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
        <?php
            $stepNum = $index + 1;
            $isCompleted = $stepNum < $current;
            $isCurrent = $stepNum === $current;
            $isUpcoming = $stepNum > $current;

            $circleBase = 'flex items-center justify-center rounded-full font-semibold shrink-0 transition-all duration-[var(--motion-normal)]';
            $circleSizes = [
                'sm' => 'w-8 h-8 text-xs',
                'md' => 'w-10 h-10 text-sm',
                'lg' => 'w-12 h-12 text-base',
            ];

            if ($isCompleted) {
                $circleClasses = $circleBase . ' ' . ($circleSizes[$size] ?? $circleSizes['md']) . ' bg-[var(--accent-500)] text-white';
                $textClasses = 'text-[var(--accent-700)] font-medium';
                $label = __('تم');
            } elseif ($isCurrent) {
                $circleClasses = $circleBase . ' ' . ($circleSizes[$size] ?? $circleSizes['md']) . ' bg-[var(--accent-500)] text-white ring-4 ring-[var(--accent-500)]/20';
                $textClasses = 'text-[var(--accent-700)] font-medium';
                $label = $step['label'] ?? $step;
            } else {
                $circleClasses = $circleBase . ' ' . ($circleSizes[$size] ?? $circleSizes['md']) . ' bg-[var(--color-bg-secondary)] text-[var(--color-text-muted)]';
                $textClasses = 'text-[var(--color-text-muted)]';
                $label = $step['label'] ?? $step;
            }
        ?>

        <div class="<?php echo e($isVertical ? 'flex items-start gap-3 pb-6 last:pb-0' : 'flex items-center gap-3'); ?>">
            <div class="flex flex-col items-center">
                <div class="<?php echo e($circleClasses); ?>">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($isCompleted): ?>
                        <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke-width="2.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M4.5 12.75l6 6 9-13.5" /></svg>
                    <?php else: ?>
                        <?php echo e($stepNum); ?>

                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>

            <div class="<?php echo e($isVertical ? 'flex flex-col' : 'hidden md:flex flex-col shrink-0'); ?>">
                <span class="text-sm <?php echo e($textClasses); ?>"><?php echo e($step['label'] ?? $step); ?></span>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(isset($step['description'])): ?>
                    <span class="text-xs text-[var(--color-text-muted)]"><?php echo e($step['description']); ?></span>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>

        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$loop->last): ?>
            <div class="<?php echo e($isVertical ? 'mr-5 w-0.5 h-8' : 'flex-1 h-0.5 mx-3'); ?> <?php echo e($stepNum < $current ? 'bg-[var(--accent-500)]' : 'bg-[var(--color-border)]'); ?>"></div>
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
</div>
<?php /**PATH /Users/maystro/Desktop/MyData/dev/web-apps/laravel13/charity/resources/views/components/ui/stepper.blade.php ENDPATH**/ ?>