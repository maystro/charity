<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'src' => null,
    'alt' => null,
    'name' => null,
    'size' => 'md',
    'status' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'src' => null,
    'alt' => null,
    'name' => null,
    'size' => 'md',
    'status' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $sizes = [
        'sm' => 'w-8 h-8 text-xs',
        'md' => 'w-10 h-10 text-sm',
        'lg' => 'w-14 h-14 text-lg',
        'xl' => 'w-20 h-20 text-xl',
    ];
    $statusSizes = [
        'sm' => 'w-2.5 h-2.5 border',
        'md' => 'w-3 h-3 border-2',
        'lg' => 'w-3.5 h-3.5 border-2',
        'xl' => 'w-4 h-4 border-2',
    ];
    $statusColors = [
        'online' => 'bg-[var(--color-success-500)]',
        'offline' => 'bg-gray-400',
        'busy' => 'bg-[var(--color-danger-500)]',
    ];

    $initials = '';
    if ($name && !$src) {
        $parts = explode(' ', trim($name));
        $initials = mb_substr($parts[0], 0, 1);
        if (count($parts) > 1) $initials .= mb_substr(end($parts), 0, 1);
        $initials = strtoupper($initials);
    }
?>

<div class="relative inline-flex shrink-0" <?php echo e($attributes); ?>>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($src): ?>
        <img src="<?php echo e($src); ?>" alt="<?php echo e($alt ?? $name); ?>" class="<?php echo e($sizes[$size] ?? $sizes['md']); ?> rounded-full object-cover" />
    <?php else: ?>
        <div class="<?php echo e($sizes[$size] ?? $sizes['md']); ?> rounded-full bg-[var(--accent-500)]/10 text-[var(--accent-700)] flex items-center justify-center font-semibold">
            <?php echo e($initials); ?>

        </div>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($status): ?>
        <span class="absolute bottom-0 <?php echo e(app()->isLocale('ar') ? 'left-0' : 'right-0'); ?> block <?php echo e($statusSizes[$size] ?? $statusSizes['md']); ?> <?php echo e($statusColors[$status] ?? $statusColors['offline']); ?> rounded-full ring-2 ring-white"></span>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH /Users/maystro/Desktop/MyData/dev/web-apps/laravel13/charity/resources/views/components/ui/avatar.blade.php ENDPATH**/ ?>