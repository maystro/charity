<?php

namespace App\Services\Deployment;

use App\Models\SmartDeployment;
use App\Models\User;
use App\Support\Deployment\ProjectSnapshot;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use RuntimeException;
use Throwable;

/**
 * Smart file deployment: upload only the files that changed since the last
 * deployment, tracked through a local manifest. Supports two comparison
 * modes:
 *
 *  - local:  diff the working tree against storage/app/deployment_manifest.json
 *  - server: diff against the files actually present on the remote host
 *            (deployer.php over HTTP when configured, otherwise FTP listing)
 */
class SmartDeploymentService
{
    protected ?FtpClientContract $client = null;

    public function __construct(
        protected ProjectSnapshot $snapshot,
    ) {
    }

    /**
     * Set the FTP client used for deployment (injectable for tests).
     */
    public function usingClient(FtpClientContract $client): static
    {
        $this->client = $client;

        return $this;
    }

    /* ---------------------------------------------------------------------
     | Scanning
     | --------------------------------------------------------------------- */

    /**
     * Scan the included paths and compute a checksum for every file.
     *
     * @return array<string, string> [relative_path => md5]
     */
    public function scanLocalFiles(): array
    {
        $include = config('deployment.smart.include', []);

        $files = $this->snapshot->scan(
            base_path(),
            ProjectSnapshot::DEFAULT_EXCLUDES,
            $include
        );

        $excludeWithin = config('deployment.smart.exclude_within', []);

        return collect($files)
            ->reject(fn (string $hash, string $path): bool => ! $this->shouldIncludeFile($path, $excludeWithin))
            ->all();
    }

    /**
     * Whether a relative path should be part of the deployment set.
     *
     * @param  array<int, string>|null  $excludeWithin
     */
    public function shouldIncludeFile(string $relativePath, ?array $excludeWithin = null): bool
    {
        if (basename($relativePath) === '.gitignore') {
            return false;
        }

        $excludeWithin ??= config('deployment.smart.exclude_within', []);

        foreach ($excludeWithin as $excluded) {
            if ($relativePath === $excluded || Str::startsWith($relativePath, $excluded.'/')) {
                return false;
            }
        }

        return true;
    }

    /**
     * Compute the total byte size of a set of relative paths.
     *
     * @param  array<int, string>  $paths
     */
    public function totalSize(array $paths): int
    {
        $size = 0;

        foreach ($paths as $path) {
            $absolute = base_path($path);
            $fileSize = is_file($absolute) ? filesize($absolute) : false;
            $size += $fileSize === false ? 0 : (int) $fileSize;
        }

        return $size;
    }

    /* ---------------------------------------------------------------------
     | Manifest
     | --------------------------------------------------------------------- */

    public function manifestPath(): string
    {
        return (string) config('deployment.smart.manifest_path', storage_path('app/deployment_manifest.json'));
    }

    /**
     * @return array<string, string>
     */
    public function loadManifest(): array
    {
        $path = $this->manifestPath();

        if (! is_file($path)) {
            return [];
        }

        $manifest = json_decode((string) file_get_contents($path), true);

        return is_array($manifest) ? $manifest : [];
    }

    /**
     * @param  array<string, string>  $manifest
     */
    public function saveManifest(array $manifest): void
    {
        $path = $this->manifestPath();

        if (! is_dir(dirname($path))) {
            mkdir(dirname($path), 0775, true);
        }

        file_put_contents($path, json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    }

    public function resetManifest(): void
    {
        $path = $this->manifestPath();

        if (is_file($path)) {
            @unlink($path);
        }
    }

    /* ---------------------------------------------------------------------
     | Change detection
     | --------------------------------------------------------------------- */

    /**
     * Diff the local tree against the manifest.
     *
     * @return array{added: array<int, string>, modified: array<int, string>, removed: array<int, string>, total_size: int}
     */
    public function getLocalChanges(): array
    {
        $current = $this->scanLocalFiles();
        $manifest = $this->loadManifest();

        return $this->diffSnapshots($manifest, $current);
    }

    /**
     * Diff the local tree against the actual server files.
     *
     * @return array{added: array<int, string>, modified: array<int, string>, removed: array<int, string>, total_size: int}
     */
    public function getServerChanges(): array
    {
        $current = $this->scanLocalFiles();
        $server = $this->getServerManifest();

        return $this->diffSnapshots($server, $current);
    }

    /**
     * Fetch the manifest of files present on the server.
     *
     * @return array<string, string> [relative_path => hash]
     */
    public function getServerManifest(): array
    {
        $serverUrl = (string) config('deployment.smart.server_url', '');

        if ($serverUrl !== '') {
            try {
                $manifest = $this->fetchHttpManifest($serverUrl);

                if ($manifest !== null) {
                    return $manifest;
                }
            } catch (Throwable) {
                // Fall back to FTP listing below.
            }
        }

        return $this->fetchFtpManifest();
    }

    /**
     * @return array<string, string>|null
     */
    protected function fetchHttpManifest(string $serverUrl): ?array
    {
        $response = Http::asForm()
            ->timeout(60)
            ->post($serverUrl, [
                'action' => 'get_manifest',
                'secret' => (string) config('deployment.smart.secret_key', ''),
            ]);

        if (! $response->successful()) {
            return null;
        }

        $data = $response->json();

        if (! is_array($data) || ($data['success'] ?? false) !== true || ! isset($data['files'])) {
            return null;
        }

        $manifest = [];

        foreach ((array) $data['files'] as $path => $hash) {
            if (is_string($path) && is_string($hash)) {
                $manifest[$path] = $hash;
            }
        }

        return $manifest;
    }

    /**
     * Walk the remote FTP tree and build [path => size-as-hash].
     *
     * @return array<string, string>
     */
    protected function fetchFtpManifest(): array
    {
        $this->connectClient();

        $manifest = [];

        foreach ($this->client->tree('') as $entry) {
            if ($entry['type'] !== 'file') {
                continue;
            }

            $path = (string) $entry['path'];

            if (! $this->shouldIncludeFile($path, config('deployment.smart.exclude_within', []))) {
                continue;
            }

            // FTP cannot hash a remote file cheaply; use size as the fingerprint.
            $manifest[$path] = 'size:'.(string) ($entry['size'] ?? 0);
        }

        $this->client->disconnect();

        return $manifest;
    }

    /**
     * @param  array<string, string>  $previous
     * @param  array<string, string>  $current
     * @return array{added: array<int, string>, modified: array<int, string>, removed: array<int, string>, total_size: int}
     */
    protected function diffSnapshots(array $previous, array $current): array
    {
        $added = [];
        $modified = [];
        $removed = [];

        foreach ($current as $path => $hash) {
            if (! array_key_exists($path, $previous)) {
                $added[] = $path;
            } elseif ($previous[$path] !== $hash) {
                $modified[] = $path;
            }
        }

        foreach ($previous as $path => $hash) {
            if (! array_key_exists($path, $current)) {
                $removed[] = $path;
            }
        }

        sort($added);
        sort($modified);
        sort($removed);

        $all = array_merge($added, $modified, $removed);

        return [
            'added' => $added,
            'modified' => $modified,
            'removed' => $removed,
            'total_size' => $this->totalSize($all),
        ];
    }

    /* ---------------------------------------------------------------------
     | Deployment
     | --------------------------------------------------------------------- */

    /**
     * Upload the given relative paths to the server, delete removed files,
     * refresh caches and update the manifest.
     *
     * @param  array{added: array<int, string>, modified: array<int, string>, removed: array<int, string>}  $changes
     * @param  callable(int, int): void|null  $onProgress  (done, total)
     * @return array{files_count: int, total_size: int, files: array<int, string>, deleted: array<int, string>}
     */
    public function deploy(array $changes, ?callable $onProgress = null): array
    {
        $this->connectClient();

        $files = array_merge($changes['added'], $changes['modified']);
        $deleted = $changes['removed'];
        $total = count($files);
        $done = 0;

        try {
            $dirs = [];

            foreach ($files as $path) {
                $dir = dirname($path);

                if ($dir !== '.' && $dir !== '' && ! in_array($dir, $dirs, true)) {
                    $dirs[] = $dir;
                }
            }

            // Batch-create directories first to reduce round-trips.
            foreach ($dirs as $dir) {
                $this->client->ensureDirectory($dir);
            }

            foreach ($files as $path) {
                $this->client->upload(base_path($path), $path);
                $done++;

                if ($onProgress !== null) {
                    $onProgress($done, $total);
                }
            }

            foreach ($deleted as $path) {
                $this->client->delete($path);
            }

            $this->clearServerCaches();
        } catch (Throwable $e) {
            $this->client->disconnect();

            throw new RuntimeException($e->getMessage());
        }

        $this->client->disconnect();

        // Update the manifest so future local scans see a clean tree.
        $current = $this->scanLocalFiles();
        $manifest = $this->loadManifest();

        foreach ($files as $path) {
            if (isset($current[$path])) {
                $manifest[$path] = $current[$path];
            }
        }

        foreach ($deleted as $path) {
            unset($manifest[$path]);
        }

        $this->saveManifest($manifest);

        return [
            'files_count' => $total,
            'total_size' => $this->totalSize($files),
            'files' => $files,
            'deleted' => $deleted,
        ];
    }

    /**
     * Clear the common Laravel cache directories on the server without exec().
     */
    protected function clearServerCaches(): void
    {
        $this->client->deleteDirectory('bootstrap/cache');
        $this->client->deleteDirectory('storage/framework/cache/data');
        $this->client->deleteDirectory('storage/framework/views');
    }

    /**
     * Open a new smart deployment record (status: deploying).
     */
    public function startRecord(?User $user = null, string $mode = 'local'): SmartDeployment
    {
        return SmartDeployment::create([
            'user_id' => $user?->id,
            'mode' => $mode,
            'status' => 'deploying',
            'files_count' => 0,
            'total_size' => 0,
            'files_list' => [],
            'started_at' => now(),
        ]);
    }

    /**
     * Mark a smart deployment record as successful.
     *
     * @param  array{files_count?: int, total_size?: int, files?: array<int, string>}  $result
     */
    public function completeRecord(SmartDeployment $record, array $result = [], ?string $notes = null, ?string $serverResponse = null): SmartDeployment
    {
        $record->update([
            'files_count' => $result['files_count'] ?? 0,
            'total_size' => $result['total_size'] ?? 0,
            'files_list' => $result['files'] ?? [],
            'notes' => $notes,
            'server_response' => $serverResponse,
            'completed_at' => now(),
            'status' => 'success',
        ]);

        return $record;
    }

    /**
     * Mark a smart deployment record as failed.
     */
    public function failRecord(SmartDeployment $record, ?string $serverResponse = null): SmartDeployment
    {
        $record->update([
            'status' => 'failed',
            'server_response' => $serverResponse,
            'completed_at' => now(),
        ]);

        return $record;
    }

    /* ---------------------------------------------------------------------
     | History & stats
     | --------------------------------------------------------------------- */

    /**
     * @return \Illuminate\Database\Eloquent\Collection<int, SmartDeployment>
     */
    public function getRecentDeployments(int $limit = 10)
    {
        return SmartDeployment::query()
            ->with('user')
            ->orderByDesc('id')
            ->limit($limit)
            ->get();
    }

    /**
     * @return array{total_files: int, total_size: int, last_deployment: SmartDeployment|null, synced: bool, manifest_exists: bool, manifest_files: int}
     */
    public function getStats(): array
    {
        $current = $this->scanLocalFiles();
        $changes = $this->getLocalChanges();

        return [
            'total_files' => count($current),
            'total_size' => $this->totalSize(array_keys($current)),
            'last_deployment' => SmartDeployment::query()->orderByDesc('id')->first(),
            'synced' => count($changes['added']) + count($changes['modified']) + count($changes['removed']) === 0,
            'manifest_exists' => is_file($this->manifestPath()),
            'manifest_files' => count($this->loadManifest()),
        ];
    }

    protected function connectClient(): void
    {
        // When a client was injected (e.g. in tests), use it as-is.
        if ($this->client !== null) {
            $this->client->connect();

            return;
        }

        $settings = app(DeploymentFtpSettings::class);

        if (! $settings->isConfigured()) {
            throw new RuntimeException('إعدادات FTP غير مكتملة — أكملها من صفحة إعدادات النشر أولاً.');
        }

        $config = $settings->all();

        $this->client = new FtpClient([
            'host' => (string) $config['host'],
            'port' => (int) ($config['port'] ?? 21),
            'username' => (string) $config['username'],
            'password' => (string) $config['password'],
            'root_path' => (string) ($config['root_path'] ?? '/'),
        ]);

        $this->client->connect();
    }
}
