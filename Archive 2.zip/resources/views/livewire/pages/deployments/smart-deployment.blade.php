<div class="space-y-6">
    <x-layout.page-header
        title="النشر الذكي"
        subtitle="رفع الملفات المتغيرة فقط مع فحص محلي أو مقارنة مباشرة مع السيرفر"
    >
        <x-slot:actions>
            <div class="flex items-center gap-2 flex-wrap">
                <x-ui.button
                    variant="secondary"
                    icon="arrow-path"
                    wire:click="scanChanges"
                    :loading="$isScanning"
                    :disabled="$isDeploying"
                >
                    فحص محلي
                </x-ui.button>
                <x-ui.button
                    variant="secondary"
                    icon="cloud-arrow-down"
                    wire:click="scanServerChanges"
                    :loading="$isScanning"
                    :disabled="$isDeploying"
                >
                    مقارنة مع السيرفر
                </x-ui.button>
                @if(count($addedFiles) + count($modifiedFiles) + count($deletedFiles) > 0 && ! $isDeploying)
                    <x-ui.button
                        variant="primary"
                        icon="rocket-launch"
                        wire:click="startDeployment"
                        :loading="$isDeploying"
                    >
                        نشر التغييرات ({{ count($addedFiles) + count($modifiedFiles) }})
                    </x-ui.button>
                @endif
            </div>
        </x-slot:actions>
    </x-layout.page-header>

    {{-- Setup warning --}}
    @unless($isFtpConfigured)
        <x-ui.alert variant="warning" :dismissible="false">
            إعدادات FTP غير مكتملة — لن تتمكن من النشر.
            <a href="{{ route('deployments.ftp-settings') }}" class="underline font-medium">أكمل الإعدادات من هنا</a>
            قبل بدء النشر.
        </x-ui.alert>
    @endunless

    @if($serverUrl === '')
        <x-ui.alert variant="info" :dismissible="false">
            لم يتم ضبط <code class="font-mono text-xs">DEPLOY_SERVER_URL</code> — المقارنة مع السيرفر ستستخدم قائمة FTP
            (حجم الملفات) بدلاً من فحص checksums عبر <code class="font-mono text-xs">deployer.php</code>.
        </x-ui.alert>
    @endif

    @if($errorMessage)
        <x-ui.alert variant="danger" :dismissible="false">
            {{ $errorMessage }}
        </x-ui.alert>
    @endif

    @if($successMessage)
        <x-ui.alert variant="success" :dismissible="false">
            {{ $successMessage }}
        </x-ui.alert>
    @endif

    {{-- Status cards --}}
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <x-ui.stat
            icon="check-badge"
            label="حالة المزامنة"
            :number="$stats['synced'] ? 'متزامن' : 'غير متزامن'"
            :variant="$stats['synced'] ? 'success' : 'warning'"
        />
        <x-ui.stat
            icon="document-text"
            label="إجمالي الملفات"
            :number="$stats['total_files']"
            variant="primary"
        />
        <x-ui.stat
            icon="archive-box"
            label="ملفات المانيفست"
            :number="$stats['manifest_files']"
            variant="neutral"
        />
        <x-ui.stat
            icon="rocket-launch"
            label="آخر نشر"
            :number="$stats['last_deployment'] ? $stats['last_deployment']->files_count . ' ملف' : '—'"
            :variant="$stats['last_deployment']?->isSuccessful() ? 'success' : 'neutral'"
        />
    </div>

    {{-- Progress --}}
    @if($isScanning)
        <x-ui.card padding>
            <div class="flex items-center gap-3 text-sm text-[var(--color-text-secondary)]">
                <x-heroicon-o-arrow-path class="w-5 h-5 animate-spin text-[var(--color-info-500)]" />
                جارٍ فحص الملفات، يرجى الانتظار...
            </div>
        </x-ui.card>
    @endif

    @if($isDeploying)
        <x-ui.card padding>
            <div class="space-y-3">
                <div class="flex items-center justify-between text-sm">
                    <span class="flex items-center gap-2 text-[var(--color-text-secondary)]">
                        <x-heroicon-o-rocket-launch class="w-4 h-4 text-[var(--accent-500)]" />
                        جارٍ رفع الملفات إلى السيرفر...
                    </span>
                    <span class="font-semibold text-[var(--color-text-primary)]" dir="ltr">
                        <span wire:stream="progress">{{ $uploadProgress }}</span>%
                    </span>
                </div>
                <div class="h-2 bg-[var(--color-bg-secondary)] rounded-full overflow-hidden">
                    <div
                        class="h-full rounded-full transition-all duration-300 bg-[var(--accent-500)]"
                        style="width: {{ $uploadProgress }}%"
                    ></div>
                </div>
            </div>
        </x-ui.card>
    @endif

    {{-- Files preview --}}
    @if(count($addedFiles) + count($modifiedFiles) + count($deletedFiles) > 0 && ! $isDeploying)
        <x-ui.card padding>
            <div class="space-y-6">
                <div class="flex items-center justify-between">
                    <h2 class="text-lg font-semibold text-[var(--color-text-primary)]">
                        الملفات التي سيتم نشرها
                        <span class="text-sm font-normal text-[var(--color-text-muted)] ms-2">
                            (الحجم الكلي: <span dir="ltr">{{ number_format($totalSize) }}</span> بايت)
                        </span>
                    </h2>
                    <x-ui.button variant="ghost" size="sm" icon="trash" wire:click="resetManifest">
                        إعادة ضبط المانيفست
                    </x-ui.button>
                </div>

                @if($addedFiles)
                    <div>
                        <h3 class="flex items-center gap-2 text-sm font-semibold text-[var(--color-success-600)] mb-2">
                            <x-heroicon-o-plus-circle class="w-4 h-4" />
                            ملفات جديدة ({{ count($addedFiles) }})
                        </h3>
                        <div class="flex flex-wrap gap-1.5">
                            @foreach($addedFiles as $file)
                                <span class="text-xs font-mono text-[var(--color-text-secondary)] bg-[var(--color-success-50)] border border-[var(--color-success-200)] rounded-md px-2 py-1" dir="ltr">{{ $file }}</span>
                            @endforeach
                        </div>
                    </div>
                @endif

                @if($modifiedFiles)
                    <div>
                        <h3 class="flex items-center gap-2 text-sm font-semibold text-[var(--color-warning-600)] mb-2">
                            <x-heroicon-o-pencil-square class="w-4 h-4" />
                            ملفات معدلة ({{ count($modifiedFiles) }})
                        </h3>
                        <div class="flex flex-wrap gap-1.5">
                            @foreach($modifiedFiles as $file)
                                <span class="text-xs font-mono text-[var(--color-text-secondary)] bg-[var(--color-warning-50)] border border-[var(--color-warning-200)] rounded-md px-2 py-1" dir="ltr">{{ $file }}</span>
                            @endforeach
                        </div>
                    </div>
                @endif

                @if($deletedFiles)
                    <div>
                        <h3 class="flex items-center gap-2 text-sm font-semibold text-[var(--color-danger-600)] mb-2">
                            <x-heroicon-o-trash class="w-4 h-4" />
                            ملفات محذوفة ({{ count($deletedFiles) }})
                        </h3>
                        <div class="flex flex-wrap gap-1.5">
                            @foreach($deletedFiles as $file)
                                <span class="text-xs font-mono text-[var(--color-text-secondary)] bg-[var(--color-danger-50)] border border-[var(--color-danger-200)] rounded-md px-2 py-1 line-through" dir="ltr">{{ $file }}</span>
                            @endforeach
                        </div>
                    </div>
                @endif
            </div>
        </x-ui.card>
    @endif

    {{-- Recent deployments --}}
    <x-ui.card padding>
        <h2 class="text-lg font-semibold text-[var(--color-text-primary)] mb-4">سجل النشر الذكي</h2>

        @if($recentDeployments->isEmpty())
            <x-ui.empty-state icon="clock" title="لا توجد عمليات نشر بعد" description="ابدأ بفحص الملفات ثم انشر التغييرات." />
        @else
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead>
                        <tr class="text-xs text-[var(--color-text-muted)] border-b border-[var(--color-border)]">
                            <th class="text-start font-medium py-2 pe-4">#</th>
                            <th class="text-start font-medium py-2 pe-4">الوضع</th>
                            <th class="text-start font-medium py-2 pe-4">الحالة</th>
                            <th class="text-start font-medium py-2 pe-4">الملفات</th>
                            <th class="text-start font-medium py-2 pe-4">الحجم</th>
                            <th class="text-start font-medium py-2 pe-4">المستخدم</th>
                            <th class="text-start font-medium py-2">التاريخ</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-[var(--color-border)]">
                        @foreach($recentDeployments as $deployment)
                            <tr class="hover:bg-[var(--color-bg-secondary)]/50">
                                <td class="py-2.5 pe-4 text-[var(--color-text-muted)] font-mono">#{{ $deployment->id }}</td>
                                <td class="py-2.5 pe-4">
                                    <x-ui.badge :variant="$deployment->mode === 'server' ? 'info' : 'neutral'" size="sm">
                                        {{ $deployment->mode === 'server' ? 'مقارنة سيرفر' : 'فحص محلي' }}
                                    </x-ui.badge>
                                </td>
                                <td class="py-2.5 pe-4">
                                    <x-ui.badge :variant="$deployment->isSuccessful() ? 'success' : ($deployment->status === 'failed' ? 'danger' : 'warning')" dot size="sm">
                                        {{ $deployment->isSuccessful() ? 'ناجح' : ($deployment->status === 'failed' ? 'فشل' : 'قيد التنفيذ') }}
                                    </x-ui.badge>
                                </td>
                                <td class="py-2.5 pe-4 font-mono text-[var(--color-text-secondary)]">{{ $deployment->files_count }}</td>
                                <td class="py-2.5 pe-4 font-mono text-[var(--color-text-secondary)]">{{ $deployment->formattedSize() }}</td>
                                <td class="py-2.5 pe-4 text-[var(--color-text-secondary)]">{{ $deployment->user?->name ?? '—' }}</td>
                                <td class="py-2.5 font-mono text-xs text-[var(--color-text-muted)]">
                                    {{ $deployment->created_at->format('Y-m-d H:i') }}
                                    @if($deployment->duration() !== null)
                                        <span class="block text-[var(--color-text-muted)]/70">({{ $deployment->duration() }} ث)</span>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endif
    </x-ui.card>
</div>
