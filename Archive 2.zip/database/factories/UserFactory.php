<?php

namespace Database\Factories;

use App\Models\Fieldworker;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

/**
 * @extends Factory<User>
 */
class UserFactory extends Factory
{
    /**
     * The current password being used by the factory.
     */
    protected static ?string $password;

    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'name' => fake()->name(),
            'username' => fake()->unique()->userName(),
            'email' => fake()->unique()->safeEmail(),
            'email_verified_at' => now(),
            'password' => static::$password ??= Hash::make('password'),
            'remember_token' => Str::random(10),
            'role' => User::ROLE_ADMIN,
        ];
    }

    /**
     * Indicate that the model's email address should be unverified.
     */
    public function unverified(): static
    {
        return $this->state(fn (array $attributes) => [
            'email_verified_at' => null,
        ]);
    }

    /**
     * مستخدم بدور مدير النظام.
     */
    public function admin(): static
    {
        return $this->state(fn (array $attributes) => [
            'role' => User::ROLE_ADMIN,
        ]);
    }

    /**
     * مستخدم عادي بصلاحيات تُمنح من لوحة المستخدمين.
     */
    public function user(): static
    {
        return $this->state(fn (array $attributes) => [
            'role' => User::ROLE_USER,
        ]);
    }

    /**
     * مستخدم بدور السوبر أدمن التقني (إدارة النشر والإصدارات فقط).
     */
    public function superAdmin(): static
    {
        return $this->state(fn (array $attributes) => [
            'role' => User::ROLE_SUPER_ADMIN,
        ]);
    }

    /**
     * مستخدم بدور مندوب ميداني (مع إنشاء سجل Fieldworker مرتبط).
     */
    public function fieldworker(): static
    {
        return $this->state(fn (array $attributes) => [
            'role' => User::ROLE_FIELDWORKER,
        ])->afterCreating(function (User $user) {
            Fieldworker::factory()->create(['user_id' => $user->id]);
        });
    }
}
