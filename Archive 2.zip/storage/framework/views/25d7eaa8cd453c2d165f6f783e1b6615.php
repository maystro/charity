<!DOCTYPE html>
<?php
    $prefs = auth()->user()?->preferences;
    $accent      = $prefs?->accent_color  ?: 'copper';
    $fontSize    = $prefs?->font_size     ?: 'medium';
    $uiDensity   = $prefs?->ui_density    ?: 'balanced';
    $reducedMotion = $prefs?->reduced_motion ? 'true' : 'false';
?>
<html
    lang="ar"
    dir="rtl"
    data-accent="<?php echo e($accent); ?>"
    data-font-size="<?php echo e($fontSize); ?>"
    data-ui-density="<?php echo e($uiDensity); ?>"
    data-reduced-motion="<?php echo e($reducedMotion); ?>"
>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($title ?? 'لوحة التحكم'); ?> - <?php echo e(config('app.name', 'منشأة خيرية')); ?></title>

    <link rel="preconnect" href="https://fonts.bunny.net">
    <link rel="stylesheet" href="https://fonts.bunny.net/css?family=tajawal:400,500,700,800">

    
    <script>
        window.SERVER_PREFS = <?php echo json_encode([
            'accent' => $accent,
            'fontSize' => $fontSize,
            'density' => $uiDensity,
            'reducedMotion' => $reducedMotion,
        ]); ?>;
    </script>
    <?php echo app('Illuminate\Foundation\Vite')->fonts(); ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot'))): ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>
<body class="bg-[var(--accent-50)] text-[var(--color-text-primary)] antialiased">
    <div id="app-shell" class="flex h-screen overflow-hidden" style="gap: var(--shell-gap); padding: var(--outer-gap);">
        
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('sidebar', []);

$__keyOuter = $__key ?? null;

$__key = null;
$__componentSlots = [];

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-193909087-0', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key, $__componentSlots);

echo $__html;

unset($__html);
unset($__key);
$__key = $__keyOuter;
unset($__keyOuter);
unset($__name);
unset($__params);
unset($__componentSlots);
unset($__split);
?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('user-preferences', []);

$__keyOuter = $__key ?? null;

$__key = null;
$__componentSlots = [];

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-193909087-1', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key, $__componentSlots);

echo $__html;

unset($__html);
unset($__key);
$__key = $__keyOuter;
unset($__keyOuter);
unset($__name);
unset($__params);
unset($__componentSlots);
unset($__split);
?>

        
        <div class="flex-1 flex flex-col h-full" style="gap: var(--shell-gap);">
            
            <header id="TOP_BAR" class="glass shrink-0 rounded-[var(--radius-xl)] flex items-center gap-3 px-4 sm:px-6 overflow-visible" style="height: 87px; background: var(--color-sidebar-bg); backdrop-filter: blur(var(--glass-blur)); border: 1px solid var(--glass-border);">
                
                <button
                    type="button"
                    onclick="window.dispatchEvent(new CustomEvent('toggle-mobile-sidebar'))"
                    class="lg:hidden p-2 rounded-lg hover:bg-black/5 transition-colors shrink-0"
                    aria-label="<?php echo e(__('ui.open_menu')); ?>"
                >
                    <svg class="w-6 h-6" style="color: var(--color-text-secondary);" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"/>
                    </svg>
                </button>

                
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(auth()->guard()->check()): ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(! auth()->user()->isSuperAdmin()): ?>
                        
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('shared.pending-approvals-stat', []);

$__keyOuter = $__key ?? null;

$__key = null;
$__componentSlots = [];

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-193909087-2', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key, $__componentSlots);

echo $__html;

unset($__html);
unset($__key);
$__key = $__keyOuter;
unset($__keyOuter);
unset($__name);
unset($__params);
unset($__componentSlots);
unset($__split);
?>

                        
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('shared.re-assessment-alerts-stat', []);

$__keyOuter = $__key ?? null;

$__key = null;
$__componentSlots = [];

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-193909087-3', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key, $__componentSlots);

echo $__html;

unset($__html);
unset($__key);
$__key = $__keyOuter;
unset($__keyOuter);
unset($__name);
unset($__params);
unset($__componentSlots);
unset($__split);
?>

                        
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('shared.new-aid-requests-stat', []);

$__keyOuter = $__key ?? null;

$__key = null;
$__componentSlots = [];

$__key ??= \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::generateKey('lw-193909087-4', $__key);

$__html = app('livewire')->mount($__name, $__params, $__key, $__componentSlots);

echo $__html;

unset($__html);
unset($__key);
$__key = $__keyOuter;
unset($__keyOuter);
unset($__name);
unset($__params);
unset($__componentSlots);
unset($__split);
?>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                
                <div class="flex-1"></div>

                
                <button
                    type="button"
                    onclick="window.dispatchEvent(new CustomEvent('open-modal', { detail: 'user-preferences' }))"
                    class="inline-flex items-center gap-2 p-2 rounded-[var(--radius-lg)] hover:bg-black/5 transition-colors shrink-0"
                    aria-label="<?php echo e(__('ui.user_menu')); ?>"
                >
                    <span class="w-9 h-9 rounded-full flex items-center justify-center text-white font-semibold text-sm shadow-sm" style="background: var(--accent-500);">
                        <?php echo e(mb_substr(auth()->user()?->name ?? 'م', 0, 1)); ?>

                    </span>
                </button>
            </header>

            
            <main id="main-content" class="flex-1 min-w-0 flex flex-col rounded-[var(--radius-xl)] bg-[var(--color-content-bg)] shadow-sm overflow-hidden">
                
                <div class="flex-1 overflow-y-auto p-6 scrollbar-thin">
                    <?php echo e($slot); ?>

                </div>
            </main>
        </div>
    </div>

    
    <?php if (isset($component)) { $__componentOriginal339c7fedf680433726dbafc2f156956f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal339c7fedf680433726dbafc2f156956f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.toast','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.toast'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal339c7fedf680433726dbafc2f156956f)): ?>
<?php $attributes = $__attributesOriginal339c7fedf680433726dbafc2f156956f; ?>
<?php unset($__attributesOriginal339c7fedf680433726dbafc2f156956f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal339c7fedf680433726dbafc2f156956f)): ?>
<?php $component = $__componentOriginal339c7fedf680433726dbafc2f156956f; ?>
<?php unset($__componentOriginal339c7fedf680433726dbafc2f156956f); ?>
<?php endif; ?>

    
    <div id="offline-overlay" class="fixed inset-0 z-[var(--z-overlay)] bg-black/30 backdrop-blur-sm hidden items-center justify-center">
        <div class="bg-white rounded-2xl p-8 shadow-xl text-center max-w-md mx-4">
            <div class="w-16 h-16 mx-auto mb-4 rounded-full bg-red-100 flex items-center justify-center">
                <svg class="w-8 h-8 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 5.636a9 9 0 010 12.728m0 0l-2.829-2.829m2.829 2.829L21 21M15.536 8.464a5 5 0 010 7.072m0 0l-2.829-2.829m-4.242 2.829a5 5 0 01-1.414-2.83m-1.414 5.658a9 9 0 01-2.167-9.238m7.824 2.167a1 1 0 111.414 1.414m-1.414-1.414L3 3"/>
                </svg>
            </div>
            <h2 class="text-xl font-bold mb-2">انقطع الاتصال بالإنترنت</h2>
            <p class="text-[var(--color-text-secondary)] mb-4">سيتم استئناف العمل تلقائيًا عند عودة الاتصال.</p>
            <div class="flex items-center justify-center gap-2 text-sm text-[var(--color-text-muted)]">
                <svg class="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                    <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                    <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <span>جاري إعادة المحاولة...</span>
            </div>
        </div>
    </div>

    
    <div id="session-modal" class="fixed inset-0 z-[var(--z-modal)] bg-black/50 backdrop-blur-sm hidden items-center justify-center">
        <div class="bg-white rounded-2xl p-8 shadow-xl text-center max-w-md mx-4">
            <div class="w-16 h-16 mx-auto mb-4 rounded-full bg-amber-100 flex items-center justify-center">
                <svg class="w-8 h-8 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4.5c-.77-.833-2.694-.833-3.464 0L3.34 16.5c-.77.833.192 2.5 1.732 2.5z"/>
                </svg>
            </div>
            <h2 class="text-xl font-bold mb-2">انتهت جلسة العمل</h2>
            <p class="text-[var(--color-text-secondary)] mb-6">انتهت الجلسة بسبب عدم النشاط. يرجى تسجيل الدخول مرة أخرى لحماية بيانات النظام.</p>
            <a href="/login" class="inline-block px-6 py-3 rounded-xl bg-[var(--accent-500)] text-white font-semibold hover:opacity-90 transition">
                تسجيل الدخول من جديد
            </a>
        </div>
    </div>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /Users/maystro/Desktop/MyData/dev/web-apps/laravel13/charity/resources/views/layouts/app.blade.php ENDPATH**/ ?>