<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'message' => __('تم الحفظ بنجاح'),
    'type' => 'success',
    'duration' => 4000,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'message' => __('تم الحفظ بنجاح'),
    'type' => 'success',
    'duration' => 4000,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $icons = [
        'success' => 'check-circle',
        'error' => 'exclamation-triangle',
        'warning' => 'exclamation-triangle',
        'info' => 'bell',
    ];
?>

<div
    x-data="{
        show: false,
        message: '<?php echo e($message); ?>',
        type: '<?php echo e($type); ?>',
        init() {
            Livewire.on('notify', (data) => {
                this.message = data.message ?? '<?php echo e($message); ?>';
                this.type = data.type ?? '<?php echo e($type); ?>';
                this.show = true;
                setTimeout(() => this.show = false, <?php echo e($duration); ?>);
            });
        }
    }"
    x-show="show"
    x-cloak
    x-transition:enter="transition ease-out duration-[var(--motion-normal)]"
    x-transition:enter-start="opacity-0 translate-y-2 scale-95"
    x-transition:enter-end="opacity-100 translate-y-0 scale-100"
    x-transition:leave="transition ease-in duration-[var(--motion-fast)]"
    x-transition:leave-start="opacity-100 translate-y-0 scale-100"
    x-transition:leave-end="opacity-0 translate-y-2 scale-95"
    class="fixed bottom-6 <?php echo e(app()->isLocale('ar') ? 'left-6' : 'right-6'); ?> z-[var(--z-toast)] max-w-sm"
    role="alert"
>
    <div class="flex items-center gap-3 px-5 py-4 rounded-[var(--radius-lg)] shadow-xl border text-sm font-medium backdrop-blur-md
        <?php echo e($type === 'success' ? 'bg-[var(--color-success-50)]/90 border-[var(--color-success-500)]/20 text-[var(--color-success-500)]' : ''); ?>

        <?php echo e($type === 'error' ? 'bg-[var(--color-danger-50)]/90 border-[var(--color-danger-500)]/20 text-[var(--color-danger-500)]' : ''); ?>

        <?php echo e($type === 'warning' ? 'bg-[var(--color-warning-50)]/90 border-[var(--color-warning-500)]/20 text-[var(--color-warning-500)]' : ''); ?>

        <?php echo e($type === 'info' ? 'bg-[var(--color-info-50)]/90 border-[var(--color-info-500)]/20 text-[var(--color-info-500)]' : ''); ?>

    ">
        <span class="w-5 h-5 flex items-center justify-center shrink-0 text-current">
            <?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal511d4862ff04963c3c16115c05a86a9d = $attributes; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => 'heroicon-s-' . ($icons[$type] ?? 'check-circle')] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\DynamicComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 text-current']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $attributes = $__attributesOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
        </span>
        <span x-text="message" class="flex-1"></span>
        <button x-on:click="show = false" class="shrink-0 p-1 rounded-lg hover:bg-black/5 text-current transition-colors">
            <svg class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
        </button>
    </div>
</div>
<?php /**PATH /Users/maystro/Desktop/MyData/dev/web-apps/laravel13/charity/resources/views/components/ui/toast.blade.php ENDPATH**/ ?>