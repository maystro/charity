<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'variant' => 'neutral',
    'size' => 'md',
    'dot' => false,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'variant' => 'neutral',
    'size' => 'md',
    'dot' => false,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $base = 'inline-flex items-center gap-1.5 font-medium rounded-full';

    $variants = [
        'primary'   => 'bg-[var(--accent-50)] text-[var(--accent-700)]',
        'secondary' => 'bg-[var(--color-bg-secondary)] text-[var(--color-text-secondary)]',
        'success'   => 'bg-[var(--color-success-50)] text-[var(--color-success-500)]',
        'danger'    => 'bg-[var(--color-danger-50)] text-[var(--color-danger-500)]',
        'warning'   => 'bg-[var(--color-warning-50)] text-[var(--color-warning-500)]',
        'info'      => 'bg-[var(--color-info-50)] text-[var(--color-info-500)]',
        'neutral'   => 'bg-gray-100 text-gray-600',
    ];

    $sizes = [
        'sm' => 'px-2 py-0.5 text-xs',
        'md' => 'px-2.5 py-1 text-xs',
        'lg' => 'px-3 py-1 text-sm',
    ];

    $dotColors = [
        'primary'   => 'bg-[var(--accent-500)]',
        'secondary' => 'bg-gray-400',
        'success'   => 'bg-[var(--color-success-500)]',
        'danger'    => 'bg-[var(--color-danger-500)]',
        'warning'   => 'bg-[var(--color-warning-500)]',
        'info'      => 'bg-[var(--color-info-500)]',
        'neutral'   => 'bg-gray-400',
    ];

    $classes = $base . ' ' . ($variants[$variant] ?? $variants['neutral']) . ' ' . ($sizes[$size] ?? $sizes['md']);
?>

<span <?php echo e($attributes->merge(['class' => $classes])); ?>>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($dot): ?>
        <span class="w-1.5 h-1.5 rounded-full <?php echo e($dotColors[$variant] ?? $dotColors['neutral']); ?>"></span>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php echo e($slot); ?>

</span>
<?php /**PATH /Users/maystro/Desktop/MyData/dev/web-apps/laravel13/charity/resources/views/components/ui/badge.blade.php ENDPATH**/ ?>