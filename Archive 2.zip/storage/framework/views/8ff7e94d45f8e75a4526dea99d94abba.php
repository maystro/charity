<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'label' => null,
    'name' => null,
    'checked' => false,
    'disabled' => false,
    'size' => 'md',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'label' => null,
    'name' => null,
    'checked' => false,
    'disabled' => false,
    'size' => 'md',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $id = $attributes->get('id', $name ?? 'switch-' . substr(md5(random_bytes(8)), 0, 8));
    $sizes = [
        'sm' => 'w-9 h-5 after:w-4 after:h-4 after:top-0.5 after:start-0.5',
        'md' => 'w-11 h-6 after:w-5 after:h-5 after:top-0.5 after:start-0.5',
        'lg' => 'w-14 h-7 after:w-6 after:h-6 after:top-0.5 after:start-0.5',
    ];
?>

<label for="<?php echo e($id); ?>" class="inline-flex items-center gap-3 cursor-pointer select-none <?php echo e($disabled ? 'opacity-50 cursor-not-allowed' : ''); ?>">
    <input
        type="checkbox"
        id="<?php echo e($id); ?>"
        name="<?php echo e($name); ?>"
        <?php if($checked): ?> checked <?php endif; ?>
        <?php if($disabled): ?> disabled <?php endif; ?>
        class="sr-only peer"
        style="top:0;left:0;"
        <?php echo e($attributes->except(['class', 'id', 'name', 'checked', 'disabled'])); ?>

    />
    <div class="relative <?php echo e($sizes[$size] ?? $sizes['md']); ?> bg-[var(--color-border-strong)] rounded-full peer-checked:bg-[var(--accent-500)] peer-focus-visible:ring-4 peer-focus-visible:ring-[var(--accent-500)]/20 transition-all duration-[var(--motion-fast)] after:content-[''] after:absolute after:bg-white after:rounded-full after:shadow-md after:transition-transform after:duration-[var(--motion-fast)] peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full">
    </div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($label): ?>
        <span class="text-sm font-medium text-[var(--color-text-primary)]"><?php echo e($label); ?></span>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</label>
<?php /**PATH /Users/maystro/Desktop/MyData/dev/web-apps/laravel13/charity/resources/views/components/ui/switch.blade.php ENDPATH**/ ?>