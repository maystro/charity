<?php

use App\Models\UserPreference;
use Livewire\Volt\Component;

?>

<div x-data="{ open: false }" @open-modal.window="if ($event.detail === 'user-preferences') open = true">
    <div
        x-show="open"
        x-cloak
        x-transition:enter="transition ease-out duration-[var(--motion-normal)]"
        x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100"
        x-transition:leave="transition ease-in duration-[var(--motion-fast)]"
        x-transition:leave-start="opacity-100"
        x-transition:leave-end="opacity-0"
        class="fixed inset-0 z-[var(--z-modal)]"
        @keydown.escape.window="open = false"
    >
        <div class="fixed inset-0 bg-black/40 backdrop-blur-sm" @click="open = false"></div>

        <div class="fixed inset-0 overflow-y-auto">
            <div class="flex min-h-full items-center justify-center p-4">
                <div
                    x-show="open"
                    x-transition:enter="transition ease-out duration-[var(--motion-normal)]"
                    x-transition:enter-start="opacity-0 scale-95"
                    x-transition:enter-end="opacity-100 scale-100"
                    x-transition:leave="transition ease-in duration-[var(--motion-fast)]"
                    x-transition:leave-start="opacity-100 scale-100"
                    x-transition:leave-end="opacity-0 scale-95"
                    class="w-full max-w-lg bg-white rounded-[var(--radius-xl)] shadow-2xl"
                >
                    <div class="flex items-start justify-between gap-4 p-5 border-b border-[var(--color-border)]">
                        <div>
                            <h3 class="text-lg font-semibold text-[var(--color-text-primary)]"><?php echo e(__('ui.interface_preferences')); ?></h3>
                            <p class="mt-1 text-sm text-[var(--color-text-muted)]">خصص مظهر النظام حسب راحتك</p>
                        </div>
                        <button @click="open = false" class="p-1 rounded-[var(--radius-sm)] text-[var(--color-text-muted)] hover:text-[var(--color-text-primary)] hover:bg-[var(--color-bg-secondary)] transition-colors">
                            <svg class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
                        </button>
                    </div>

                    <div class="p-5 space-y-6">
                        
                        <div>
                            <label class="block text-sm font-medium mb-3 text-[var(--color-text-primary)]"><?php echo e(__('ui.accent_color')); ?></label>
                            <div class="grid grid-cols-4 gap-3">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $this->accentOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <label class="relative cursor-pointer">
                                        <input type="radio" wire:model.live="accentColor" value="<?php echo e($key); ?>" class="sr-only peer">
                                        <div class="flex flex-col items-center gap-2 p-3 rounded-[var(--radius-md)] border border-[var(--color-border)] hover:bg-[var(--color-bg-secondary)] peer-checked:border-[var(--accent-500)] peer-checked:bg-[var(--accent-50)] transition-colors">
                                            <span class="w-8 h-8 rounded-full shadow-sm" style="background: <?php echo e($option['color']); ?>;"></span>
                                            <span class="text-xs text-[var(--color-text-secondary)]"><?php echo e($option['label']); ?></span>
                                        </div>
                                        <div class="absolute top-2 left-2 w-4 h-4 rounded-full bg-[var(--accent-500)] text-white items-center justify-center hidden peer-checked:flex">
                                            <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7" /></svg>
                                        </div>
                                    </label>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </div>
                        </div>

                        
                        <div>
                            <label class="block text-sm font-medium mb-3 text-[var(--color-text-primary)]"><?php echo e(__('ui.font_size')); ?></label>
                            <div class="flex rounded-[var(--radius-md)] border border-[var(--color-border)] p-1 bg-[var(--color-bg-secondary)]">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = ['small' => 'صغير', 'medium' => 'متوسط', 'large' => 'كبير']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <label class="flex-1 cursor-pointer">
                                        <input type="radio" wire:model.live="fontSize" value="<?php echo e($key); ?>" class="sr-only peer">
                                        <div class="text-center py-2 rounded-[var(--radius-sm)] text-sm text-[var(--color-text-secondary)] peer-checked:bg-white peer-checked:text-[var(--accent-600)] peer-checked:shadow-sm transition-colors">
                                            <?php echo e($label); ?>

                                        </div>
                                    </label>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </div>
                        </div>

                        
                        <div>
                            <label class="block text-sm font-medium mb-3 text-[var(--color-text-primary)]"><?php echo e(__('ui.ui_density')); ?></label>
                            <div class="flex rounded-[var(--radius-md)] border border-[var(--color-border)] p-1 bg-[var(--color-bg-secondary)]">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = ['compact' => 'مضغوط', 'balanced' => 'متوازن', 'spacious' => 'واسع']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                                    <label class="flex-1 cursor-pointer">
                                        <input type="radio" wire:model.live="uiDensity" value="<?php echo e($key); ?>" class="sr-only peer">
                                        <div class="text-center py-2 rounded-[var(--radius-sm)] text-sm text-[var(--color-text-secondary)] peer-checked:bg-white peer-checked:text-[var(--accent-600)] peer-checked:shadow-sm transition-colors">
                                            <?php echo e($label); ?>

                                        </div>
                                    </label>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </div>
                        </div>

                        
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm font-medium text-[var(--color-text-primary)]"><?php echo e(__('ui.sidebar_collapsed')); ?></p>
                                <p class="text-xs text-[var(--color-text-muted)]">تقليل عرض القائمة الجانبية</p>
                            </div>
                            <?php if (isset($component)) { $__componentOriginalb8acc5366da40f0aa58d3e22c67301ae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb8acc5366da40f0aa58d3e22c67301ae = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.switch','data' => ['wire:model.live' => 'sidebarCollapsed']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.switch'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.live' => 'sidebarCollapsed']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb8acc5366da40f0aa58d3e22c67301ae)): ?>
<?php $attributes = $__attributesOriginalb8acc5366da40f0aa58d3e22c67301ae; ?>
<?php unset($__attributesOriginalb8acc5366da40f0aa58d3e22c67301ae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb8acc5366da40f0aa58d3e22c67301ae)): ?>
<?php $component = $__componentOriginalb8acc5366da40f0aa58d3e22c67301ae; ?>
<?php unset($__componentOriginalb8acc5366da40f0aa58d3e22c67301ae); ?>
<?php endif; ?>
                        </div>

                        
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm font-medium text-[var(--color-text-primary)]"><?php echo e(__('ui.reduced_motion')); ?></p>
                                <p class="text-xs text-[var(--color-text-muted)]">إيقاف التأثيرات الحركية</p>
                            </div>
                            <?php if (isset($component)) { $__componentOriginalb8acc5366da40f0aa58d3e22c67301ae = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb8acc5366da40f0aa58d3e22c67301ae = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.switch','data' => ['wire:model.live' => 'reducedMotion']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.switch'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:model.live' => 'reducedMotion']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb8acc5366da40f0aa58d3e22c67301ae)): ?>
<?php $attributes = $__attributesOriginalb8acc5366da40f0aa58d3e22c67301ae; ?>
<?php unset($__attributesOriginalb8acc5366da40f0aa58d3e22c67301ae); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb8acc5366da40f0aa58d3e22c67301ae)): ?>
<?php $component = $__componentOriginalb8acc5366da40f0aa58d3e22c67301ae; ?>
<?php unset($__componentOriginalb8acc5366da40f0aa58d3e22c67301ae); ?>
<?php endif; ?>
                        </div>
                    </div>

                    <div class="flex justify-end gap-2 p-5 border-t border-[var(--color-border)]">
                        <?php if (isset($component)) { $__componentOriginala8bb031a483a05f647cb99ed3a469847 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala8bb031a483a05f647cb99ed3a469847 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.button','data' => ['variant' => 'secondary','@click' => 'open = false']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['variant' => 'secondary','@click' => 'open = false']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>
إغلاق <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $attributes = $__attributesOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__attributesOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8bb031a483a05f647cb99ed3a469847)): ?>
<?php $component = $__componentOriginala8bb031a483a05f647cb99ed3a469847; ?>
<?php unset($__componentOriginala8bb031a483a05f647cb99ed3a469847); ?>
<?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH /Users/maystro/Desktop/MyData/dev/web-apps/laravel13/charity/resources/views/livewire/shared/user-preferences.blade.php ENDPATH**/ ?>