<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'variant' => 'default',
    'padding' => true,
    'hover' => false,
    'as' => 'div',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'variant' => 'default',
    'padding' => true,
    'hover' => false,
    'as' => 'div',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $classes = 'rounded-[var(--radius-lg)] border transition-all duration-[var(--motion-fast)]';

    $variants = [
        'default'     => 'bg-white border-[var(--color-border)] shadow-xs hover:shadow-sm',
        'stat'        => 'bg-white border-[var(--color-border)] shadow-xs hover:shadow-sm',
        'glass'       => 'glass border-[var(--glass-border)] shadow-xs',
        'interactive' => 'bg-white border-[var(--color-border)] shadow-xs hover:shadow-md hover:scale-[1.005] hover:border-[var(--accent-500)]/30 cursor-pointer',
    ];

    $classes .= ' ' . ($variants[$variant] ?? $variants['default']);
    if ($padding) $classes .= ' p-5';
    if ($hover && $variant !== 'interactive') $classes .= ' hover:shadow-md hover:scale-[1.005]';
?>

<<?php echo e($as); ?> <?php echo e($attributes->merge(['class' => $classes])); ?>>
    <?php echo e($slot); ?>

</<?php echo e($as); ?>>
<?php /**PATH /Users/maystro/Desktop/MyData/dev/web-apps/laravel13/charity/resources/views/components/ui/card.blade.php ENDPATH**/ ?>