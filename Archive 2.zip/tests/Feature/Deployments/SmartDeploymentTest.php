<?php

namespace Tests\Feature\Deployments;

use App\Models\SmartDeployment;
use App\Models\User;
use App\Services\Deployment\FtpClient;
use App\Services\Deployment\FtpClientContract;
use App\Services\Deployment\SmartDeploymentService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;
use RuntimeException;
use Tests\TestCase;

/**
 * Fake FTP client for smart deployment tests — no network calls.
 */
class SmartFakeFtpClient implements FtpClientContract
{
    /** @var array<int, array{path: string, type: 'file'|'dir', size: ?int}> */
    public array $remoteFiles = [];

    /** @var array<int, array{0: string, 1: string}> */
    public array $uploaded = [];

    /** @var array<int, string> */
    public array $deleted = [];

    /** @var array<int, string> */
    public array $createdDirs = [];

    /** @var array<int, string> */
    public array $clearedDirs = [];

    public bool $failConnect = false;

    public function connect(): void
    {
        if ($this->failConnect) {
            throw new RuntimeException('Connection refused');
        }
    }

    public function reconnect(): void
    {
        $this->connect();
    }

    public function ensureDirectory(string $remoteDir): void
    {
        $this->createdDirs[] = $remoteDir;
    }

    public function upload(string $localPath, string $remotePath): void
    {
        $this->uploaded[] = [$localPath, $remotePath];
    }

    public function delete(string $remotePath): void
    {
        $this->deleted[] = $remotePath;
    }

    public function listDirectory(string $remoteDir): array
    {
        return [];
    }

    public function tree(string $remoteDir = ''): array
    {
        return $this->remoteFiles;
    }

    public function download(string $remotePath, string $localPath): void
    {
        file_put_contents($localPath, 'remote');
    }

    public function deleteDirectory(string $remoteDir): void
    {
        $this->clearedDirs[] = $remoteDir;
    }

    public function disconnect(): void
    {
    }
}

class SmartDeploymentTest extends TestCase
{
    use RefreshDatabase;

    private string $manifestPath;

    private string $tempFile;

    private string $tempDir;

    protected function setUp(): void
    {
        parent::setUp();

        $this->manifestPath = (string) config('deployment.smart.manifest_path');
        $this->tempDir = storage_path('app/smart-test-'.uniqid());
        $this->tempFile = $this->tempDir.'/routes_temp_test.php';

        mkdir($this->tempDir.'/routes', 0777, true);
        file_put_contents($this->tempFile, "<?php // smart test\n");
    }

    protected function tearDown(): void
    {
        @unlink($this->manifestPath);
        @unlink($this->tempFile);
        @rmdir($this->tempDir.'/routes');
        @rmdir($this->tempDir);

        parent::tearDown();
    }

    private function superAdmin(): User
    {
        return User::factory()->superAdmin()->create();
    }

    private function service(?SmartFakeFtpClient $client = null): SmartDeploymentService
    {
        $service = app(SmartDeploymentService::class);

        return $service->usingClient($client ?? new SmartFakeFtpClient());
    }

    public function test_scan_local_reports_everything_added_when_manifest_missing(): void
    {
        $service = $this->service();

        $changes = $service->getLocalChanges();

        $this->assertContains('app/Support/Navigation.php', $changes['added']);
        $this->assertNotContains('app/Support/Navigation.php', $changes['modified']);
        $this->assertSame([], $changes['removed']);
        $this->assertGreaterThan(0, $changes['total_size']);
    }

    public function test_scan_local_reports_synced_after_manifest_saved(): void
    {
        $service = $this->service();

        $current = $service->scanLocalFiles();
        $service->saveManifest($current);

        $changes = $service->getLocalChanges();

        $this->assertSame([], $changes['added']);
        $this->assertSame([], $changes['modified']);
        $this->assertSame([], $changes['removed']);
    }

    public function test_scan_local_detects_modified_file(): void
    {
        $service = $this->service();

        $current = $service->scanLocalFiles();
        $current['app/Support/Navigation.php'] = 'changed-hash';
        $service->saveManifest($current);

        $changes = $service->getLocalChanges();

        $this->assertContains('app/Support/Navigation.php', $changes['modified']);
    }

    public function test_scan_local_reports_removed_files(): void
    {
        $service = $this->service();

        $current = $service->scanLocalFiles();
        $current['routes/__gone__.php'] = 'hash';
        $service->saveManifest($current);

        $changes = $service->getLocalChanges();

        $this->assertContains('routes/__gone__.php', $changes['removed']);
    }

    public function test_server_changes_uses_ftp_tree_when_no_server_url(): void
    {
        config(['deployment.smart.server_url' => '']);

        $client = new SmartFakeFtpClient;
        $client->remoteFiles = [
            ['path' => 'routes/only-on-server.php', 'type' => 'file', 'size' => 999],
        ];

        $service = $this->service($client);
        $changes = $service->getServerChanges();

        // File on server but not locally → must be deleted from the server.
        $this->assertContains('routes/only-on-server.php', $changes['removed']);
        // File present on server but outside include → must not appear.
        $this->assertNotContains('vendor/autoload.php', $changes['removed']);
        // Local files missing on the server → must be uploaded.
        $this->assertContains('app/Support/Navigation.php', $changes['added']);
    }

    public function test_server_changes_uses_http_manifest_when_server_url_set(): void
    {
        config(['deployment.smart.server_url' => 'https://example.com/deployer.php']);
        config(['deployment.smart.secret_key' => 'test-secret']);

        Http::fake([
            'https://example.com/deployer.php' => Http::response([
                'success' => true,
                'files' => [
                    'app/Models/User.php' => md5('old-content'),
                ],
            ]),
        ]);

        $client = new SmartFakeFtpClient;

        $changes = $this->service($client)->getServerChanges();

        // File exists locally but differs from the server hash → modified.
        $this->assertContains('app/Models/User.php', $changes['modified']);

        Http::assertSent(function ($request) {
            return $request->url() === 'https://example.com/deployer.php'
                && $request['action'] === 'get_manifest'
                && $request['secret'] === 'test-secret';
        });
    }

    public function test_connect_uses_short_timeout_when_configured(): void
    {
        $client = new FtpClient([
            'host' => '10.255.255.1',
            'port' => 21,
            'username' => 'demo',
            'password' => 'demo',
            'root_path' => '/',
        ], passive: true, timeout: 1);

        $start = microtime(true);

        try {
            $client->connect();
            $this->fail('Expected FTP connection to fail for unreachable host.');
        } catch (RuntimeException $exception) {
            $this->assertStringContainsString('تعذر الاتصال', $exception->getMessage());
        }

        $this->assertLessThan(5, microtime(true) - $start);
    }

    public function test_should_include_file_excludes_gitignore_and_configured_paths(): void
    {
        $service = $this->service();

        $this->assertFalse($service->shouldIncludeFile('.gitignore'));
        $this->assertFalse($service->shouldIncludeFile('public/storage/logo.png'));
        $this->assertFalse($service->shouldIncludeFile('bootstrap/cache/config.php'));
        $this->assertTrue($service->shouldIncludeFile('app/Models/User.php'));
    }

    public function test_deploy_uploads_added_and_modified_files_and_saves_manifest(): void
    {
        $client = new SmartFakeFtpClient;
        $service = $this->service($client);

        $result = $service->deploy([
            'added' => ['app/Support/Navigation.php'],
            'modified' => [],
            'removed' => ['routes/old.php'],
        ]);

        $this->assertCount(1, $client->uploaded);
        $this->assertSame('app/Support/Navigation.php', $client->uploaded[0][1]);
        $this->assertContains('routes/old.php', $client->deleted);
        $this->assertSame(1, $result['files_count']);

        // Manifest must now mark the uploaded file as in sync.
        $manifest = $service->loadManifest();
        $this->assertArrayHasKey('app/Support/Navigation.php', $manifest);

        // Caches cleared.
        $this->assertContains('bootstrap/cache', $client->clearedDirs);
        $this->assertContains('storage/framework/views', $client->clearedDirs);
    }

    public function test_deploy_reports_progress_callback(): void
    {
        $client = new SmartFakeFtpClient;
        $service = $this->service($client);

        $progress = [];

        $service->deploy(
            [
                'added' => ['app/Support/Navigation.php', 'routes/web.php'],
                'modified' => [],
                'removed' => [],
            ],
            function (int $done, int $total) use (&$progress): void {
                $progress[] = [$done, $total];
            }
        );

        $this->assertSame([1, 2], $progress[0]);
        $this->assertSame([2, 2], $progress[1]);
    }

    public function test_deploy_throws_when_ftp_not_configured(): void
    {
        // No FTP settings stored in DB, none in config.
        config(['deployment.ftp.host' => null]);
        config(['deployment.ftp.username' => null]);
        config(['deployment.ftp.password' => null]);

        $service = app(SmartDeploymentService::class);

        $this->expectException(RuntimeException::class);

        $service->deploy([
            'added' => ['app/Support/Navigation.php'],
            'modified' => [],
            'removed' => [],
        ]);
    }

    public function test_reset_manifest_deletes_manifest_file(): void
    {
        $service = $this->service();
        $service->saveManifest(['app/Models/User.php' => 'hash']);

        $this->assertFileExists($service->manifestPath());

        $service->resetManifest();

        $this->assertFileDoesNotExist($service->manifestPath());
    }

    public function test_stats_reports_totals_and_sync_state(): void
    {
        $service = $this->service();

        $stats = $service->getStats();

        $this->assertGreaterThan(0, $stats['total_files']);
        $this->assertSame(false, $stats['synced']);
        $this->assertSame(false, $stats['manifest_exists']);

        $service->saveManifest($service->scanLocalFiles());

        $stats = $service->getStats();
        $this->assertSame(true, $stats['synced']);
        $this->assertSame(true, $stats['manifest_exists']);
        $this->assertSame($stats['total_files'], $stats['manifest_files']);
    }

    public function test_start_and_complete_record_persists_history(): void
    {
        $user = $this->superAdmin();
        $service = $this->service();

        $record = $service->startRecord($user, 'local');

        $this->assertDatabaseHas('smart_deployments', [
            'id' => $record->id,
            'status' => 'deploying',
        ]);

        $service->completeRecord($record, [
            'files_count' => 3,
            'total_size' => 1024,
            'files' => ['a.php', 'b.php', 'c.php'],
        ], notes: 'deployed');

        $this->assertDatabaseHas('smart_deployments', [
            'id' => $record->id,
            'status' => 'success',
            'files_count' => 3,
            'total_size' => 1024,
        ]);

        $this->assertSame(['a.php', 'b.php', 'c.php'], $record->fresh()->files_list);
        $this->assertSame('1 KB', $record->fresh()->formattedSize());
    }

    public function test_fail_record_marks_failure(): void
    {
        $service = $this->service();
        $record = $service->startRecord(null, 'server');

        $service->failRecord($record, 'Connection lost');

        $this->assertDatabaseHas('smart_deployments', [
            'id' => $record->id,
            'status' => 'failed',
            'server_response' => 'Connection lost',
        ]);
    }

    public function test_recent_deployments_returns_latest_first(): void
    {
        SmartDeployment::factory()->count(3)->create();

        $recent = $this->service()->getRecentDeployments(2);

        $this->assertCount(2, $recent);
    }

    public function test_page_requires_super_admin(): void
    {
        $user = User::factory()->create();

        $this->actingAs($user)
            ->get(route('deployments.smart-deployment'))
            ->assertForbidden();
    }

    public function test_page_loads_for_super_admin(): void
    {
        $user = $this->superAdmin();

        $this->actingAs($user)
            ->get(route('deployments.smart-deployment'))
            ->assertOk()
            ->assertSee('النشر الذكي')
            ->assertSee('فحص محلي')
            ->assertSee('مقارنة مع السيرفر');
    }
}
